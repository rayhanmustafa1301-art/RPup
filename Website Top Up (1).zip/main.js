document.addEventListener('DOMContentLoaded', () => {
    const btnEnter = document.getElementById('btn-enter');
    const startingPage = document.getElementById('starting-page');
    const mainMenu = document.getElementById('main-menu');
    const headNotif = document.getElementById('head-notif');
    
    const menuToggle = document.getElementById('menu-toggle');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const seeMore = document.getElementById('see-more');
    const subMenu = document.getElementById('gaming-submenu');

    // 1. Logika Masuk & Deteksi Resolusi
    btnEnter.addEventListener('click', () => {
        const isDesktop = window.innerWidth >= 700;

        if (!isDesktop) {
            headNotif.classList.add('show');
            setTimeout(() => headNotif.classList.remove('show'), 4000);
        } else {
            // Animasi Transisi
            startingPage.style.opacity = "0";
            setTimeout(() => {
                startingPage.style.display = "none";
                mainMenu.style.display = "block";
                setTimeout(() => {
                    mainMenu.classList.remove('hidden');
                    mainMenu.classList.add('active');
                }, 50);
            }, 600);
        }
    });

    // 2. Sidebar Toggle
    menuToggle.addEventListener('click', () => {
        sidebar.classList.toggle('open');
        overlay.classList.toggle('active');
    });

    overlay.addEventListener('click', () => {
        sidebar.classList.remove('open');
        overlay.classList.remove('active');
    });

    // 3. See More Toggle
    seeMore.addEventListener('click', () => {
        subMenu.classList.toggle('active');
        seeMore.textContent = subMenu.classList.contains('active') ? "show less" : "see more";
    });

    // 4. Pencarian Sederhana
    const searchInput = document.getElementById('search-input');
    const cards = document.querySelectorAll('.game-card');

    searchInput.addEventListener('input', (e) => {
        const val = e.target.value.toLowerCase();
        cards.forEach(card => {
            const name = card.getAttribute('data-name').toLowerCase();
            card.style.display = name.includes(val) ? "flex" : "none";
        });
    });
});
